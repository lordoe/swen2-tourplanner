package at.fhtw.swen2.tutorial.presentation;

import javafx.stage.Stage;

public interface StageAware {
    void setStage(Stage stage);
}
