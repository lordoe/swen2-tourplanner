package at.fhtw.swen2.tutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Swen2TemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
